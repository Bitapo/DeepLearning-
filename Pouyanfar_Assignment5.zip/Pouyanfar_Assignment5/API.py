import flask
import sys
from datetime import date
import numpy as np
from PIL import Image
import tensorflow as tf
from tensorflow import keras
import keras_preprocessing
from keras_preprocessing import image
from keras_preprocessing.image import ImageDataGenerator

validation_datagen = ImageDataGenerator(rescale = 1. / 255)
model = keras.models.load_model("rps.h5")
labels = {0:"Paper",1:"Rock",2:"Scissors"}

app = flask.Flask(__name__)
app.config["DEBUG"] = False

@app.route('/', methods = ['GET'])
def home():
    today = date.today().strftime("%B %d, %Y")

    return f"""Rock, Paper and Scissors image classification server.
Bita..
{today}  
"""
@app.route('/<s>', methods = ['GET'])
def query(s):
    today = date.today().strftime("%B %d, %Y")
    Img = Image.open(s).resize((150,150))
    #Img = validation_datagen.apply_transform(np.array(Img), {})
    Img = np.array(Img)[:,:,:3].astype("float32")/255
    Img = np.expand_dims(Img,axis = 0)
    result = model.predict(Img)[0].argmax()
    result = labels[result]
    return f"""Rock, Paper and Scissors image classification server.
Bita..
{today}

The image you’ve submitted is classified as a: {result} 
"""
app.run()