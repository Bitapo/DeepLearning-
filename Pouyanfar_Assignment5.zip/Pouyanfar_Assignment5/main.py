import requests
import sys
args = sys.argv[1:]
if args:
    response = requests.get(f"http://127.0.0.1:5000/{args[0]}")
    print(response.text)
else:
    response = requests.get("http://127.0.0.1:5000/")
    print(response.text)
