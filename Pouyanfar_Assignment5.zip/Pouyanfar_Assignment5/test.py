import flask
import sys
import numpy as np

from PIL import Image
import tensorflow as tf
from tensorflow import keras
import keras_preprocessing
from keras_preprocessing import image
from keras_preprocessing.image import ImageDataGenerator

validation_datagen = ImageDataGenerator(rescale = 1. / 255)
model = keras.models.load_model("rps.h5")
s = "rock01-007.png"
Img = Image.open(s)
Img = np.array(Img)[:150,:150,:3].astype("float32")/255
Img = np.expand_dims(Img,axis = 0)
result = model.predict(Img)